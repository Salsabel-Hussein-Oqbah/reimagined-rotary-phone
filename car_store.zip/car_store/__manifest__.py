# -*- coding: utf-8 -*-
{
  'name': 'Car Store',
  'version': '1.0',
  'category': 'Accounting/Accounting',
  'author': 'Salsaabel Techon Solutions',
  'website': "",
  'company': 'Salsaabel Techon Solutions',
  'maintainer': 'Salsaabel Techon Solutions',
  'summary': 'Record Car Details',
  "description": "",
  'depends': ['base'],
   'data': [
      'security/ir.model.access.csv',
      'views/car_store_views.xml',
  ],
  'installable':True,
  'application':True,
  'license':'LGPL-3',
 
}